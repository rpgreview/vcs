d1_DefenderList[0]->callback((Fl_Callback*)cb_d1_DefenderList0);
d1_CombatWeaponUsed[0]->callback((Fl_Callback*)cb_d1_CombatWeaponUsed0);
d1_CombatSpecAttk[0]->callback((Fl_Callback*)cb_d1_CombatSpecAttk0);
d1_CombatCalc[0][0]->callback((Fl_Callback*)cb_d1_CombatCalc01);
d1_CombatCalc[0][1]->callback((Fl_Callback*)cb_d1_CombatCalc02);
d1_CombatCalc[0][2]->callback((Fl_Callback*)cb_d1_CombatCalc03);
d1_CombatAcceptThis[0]->callback((Fl_Callback*)cb_d1_CombatAcceptThis0);
d1_CombatAcceptAll[0]->callback((Fl_Callback*)cb_d1_CombatAcceptAll0);
d1_CombatModifiers[0]->callback((Fl_Callback*)cb_d10_CombatModifiers0);

d1_DefenderList[1]->callback((Fl_Callback*)cb_d1_DefenderList1);
d1_CombatWeaponUsed[1]->callback((Fl_Callback*)cb_d1_CombatWeaponUsed1);
d1_CombatSpecAttk[1]->callback((Fl_Callback*)cb_d1_CombatSpecAttk1);
d1_CombatCalc[1][0]->callback((Fl_Callback*)cb_d1_CombatCalc11);
d1_CombatCalc[1][1]->callback((Fl_Callback*)cb_d1_CombatCalc12);
d1_CombatCalc[1][2]->callback((Fl_Callback*)cb_d1_CombatCalc13);
d1_CombatAcceptThis[1]->callback((Fl_Callback*)cb_d1_CombatAcceptThis1);
d1_CombatAcceptAll[1]->callback((Fl_Callback*)cb_d1_CombatAcceptAll1);
d1_CombatModifiers[1]->callback((Fl_Callback*)cb_d10_CombatModifiers1);

d1_DefenderList[2]->callback((Fl_Callback*)cb_d1_DefenderList2);
d1_CombatWeaponUsed[2]->callback((Fl_Callback*)cb_d1_CombatWeaponUsed2);
d1_CombatSpecAttk[2]->callback((Fl_Callback*)cb_d1_CombatSpecAttk2);
d1_CombatCalc[2][0]->callback((Fl_Callback*)cb_d1_CombatCalc21);
d1_CombatCalc[2][1]->callback((Fl_Callback*)cb_d1_CombatCalc22);
d1_CombatCalc[2][2]->callback((Fl_Callback*)cb_d1_CombatCalc23);
d1_CombatAcceptThis[2]->callback((Fl_Callback*)cb_d1_CombatAcceptThis2);
d1_CombatAcceptAll[2]->callback((Fl_Callback*)cb_d1_CombatAcceptAll2);
d1_CombatModifiers[2]->callback((Fl_Callback*)cb_d10_CombatModifiers2);

d1_DefenderList[3]->callback((Fl_Callback*)cb_d1_DefenderList3);

d1_CombatCalc[4][0]->callback((Fl_Callback*)cb_d1_CombatCalc41);
d1_CombatAcceptThis[4]->callback((Fl_Callback*)cb_d1_CombatAcceptThis4);
d1_CombatAcceptAll[4]->callback((Fl_Callback*)cb_d1_CombatAcceptAll4);
d1_CombatModifiers[4]->callback((Fl_Callback*)cb_d10_CombatModifiers4);

d1_CombatD100Roll[0]->callback((Fl_Callback*)cb_d1_CombatD100Roll1);
d1_CombatD100Roll[1]->callback((Fl_Callback*)cb_d1_CombatD100Roll2);
d1_CombatD100Roll[2]->callback((Fl_Callback*)cb_d1_CombatD100Roll3);
d1_CombatD100Roll[3]->callback((Fl_Callback*)cb_d1_CombatD100Roll4);
d1_CombatD100Roll[4]->callback((Fl_Callback*)cb_d1_CombatD100Roll5);

d1_CombatAcceptThis[3]->callback((Fl_Callback*)cb_d1_CombatAcceptThis3);
d1_CombatAcceptAll[3]->callback((Fl_Callback*)cb_d1_CombatAcceptAll3);
